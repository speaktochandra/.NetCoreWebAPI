﻿namespace BeerProject.Models.Repository
{
    public interface IDataRepository<TEntity, TDto>
    {
        IEnumerable<TEntity> GetAll(decimal? gtAlcoholByVolume =null, decimal? ltAlcoholByVolume = null);
        IEnumerable<TEntity> GetAll();
        IEnumerable<TEntity> GetAllWithAssociatedEntity();
        TEntity Get(long id);
        TEntity GetWithAssociatedEntity(long id);
        void Add(TEntity entity);
        void Update(TEntity entityToUpdate, TEntity entity);
        
    }
}
