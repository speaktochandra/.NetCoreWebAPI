﻿using BeerProject.Models.DTO;
using BeerProject.Models;
using BeerProject.Models.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System;

namespace BeerProject.Controllers
{
    [Route("/bar")]
    [ApiController]
    public class BarController : Controller
    {
        private readonly IDataRepository<Bar, BarDto> _dataRepository;

        public BarController(IDataRepository<Bar, BarDto> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpPost]
        //EndPoint for below 2 cases
        //Case1: - POST /bar - Insert a single bar
        //Case2: - POST /bar/beer - Insert a single bar beer link
        //If beer is not provided in JSON, it will be Case1, else it will be Case2 - Bar with associated beer will be inseted.

        public IActionResult Post([FromBody] Bar bar)
        {
            if (bar is null)
            {
                return BadRequest("Bar is null.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            _dataRepository.Add(bar);
            return CreatedAtRoute("GetBar", new { Id = bar.Id }, null);
        }

        [HttpPut("{id}")]
        // Endpoint to Update the Bar details by id
        //- PUT /bar/{id} - Update a bar by Id
        public IActionResult Put(int id, [FromBody] Bar bar)
        {
            if (bar == null)
            {
                return BadRequest("Bar is null.");
            }

            var barToUpdate = _dataRepository.Get(id);
            if (barToUpdate == null)
            {
                return NotFound("The Bar record couldn't be found.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            _dataRepository.Update(barToUpdate, bar);
            return NoContent();
        }

        [HttpGet("{id}", Name = "GetBar")]
        // Endpoint to get Bar by id
        //- GET /bar/{id} - Get bar by Id
        public IActionResult Get(int id)
        {
            var bar = _dataRepository.Get(id);
            if (bar == null)
            {
                return NotFound("Bar not found.");
            }

            return Ok(bar);
        }


        [Route("/bar/barId/beer")]
        [HttpGet]
        // Endpoint to get Bar (along with associated beers) by id 
        //- GET /bar/{barId}/beer - Get a single bar with associated beers
        public IActionResult Get(long barId)
        {
            var bar = _dataRepository.GetWithAssociatedEntity(barId);
            if (bar == null)
            {
                return NotFound("Bar not found.");
            }

            return Ok(bar);
        }

        [HttpGet]
        // Enpoint to get All Bars
        //- GET /bar - Get all bars
        public IActionResult Get()
        {
            var bars = _dataRepository.GetAll();
            return Ok(bars);
        }

        [Route("/bar/beer")]
        [HttpGet]
        // Enpoint to get All Bars with associated beers
        //- GET /bar/beer - Get all bars with associated beers
        public IActionResult Get(string? beer)
        {
            var bar = _dataRepository.GetAllWithAssociatedEntity();
            if (bar == null)
            {
                return NotFound("Bar not found.");
            }

            return Ok(bar);
        }

        
       

        
      

     

       }
}
