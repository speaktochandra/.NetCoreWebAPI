﻿using BeerProject.Models.DTO;
using BeerProject.Models.Repository;
using Microsoft.EntityFrameworkCore;

namespace BeerProject.Models.DataManager
{

    public class BreweryDataManager : IDataRepository<Brewery, BreweryDto>
    {
        readonly BeerStoreContext _beerStoreContext;

        public BreweryDataManager(BeerStoreContext storeContext)
        {
            _beerStoreContext = storeContext;
        }

        // Get all Breweries from DB using EF Core
        public IEnumerable<Brewery> GetAll()
        {
            return _beerStoreContext.Breweries
               .ToList();
        }

        // Get all Breweries from DB with associated Beers.
        public IEnumerable<Brewery> GetAllWithAssociatedEntity()
        {
            return _beerStoreContext.Breweries
                  .Include(bar => bar.Beers)
                 .ToList();
        }

        // Get Brewery by passing BreweryId
        public Brewery Get(long id)
        {
            var Brewery = _beerStoreContext.Breweries
                .SingleOrDefault(b => b.Id == id);

            if (Brewery == null)
            {
                return null;
            }

            return Brewery;
        }

        // Get Brewery along with associated beers by passing BreweryId
        public Brewery GetWithAssociatedEntity(long id)
        {

            var brewery = _beerStoreContext.Breweries
                .Include(b => b.Beers)
                .SingleOrDefault(b => b.Id == id);

            if (brewery == null)
            {
                return null;
            }

            return brewery;
        }
         
        // Insert Brewery to DB
        public void Add(Brewery entity)
        {
            _beerStoreContext.Breweries.Add(entity);
            _beerStoreContext.SaveChanges();
        }

        // Update Brewery back to DB
        public void Update(Brewery entityToUpdate, Brewery entity)
        {
            entityToUpdate = _beerStoreContext.Breweries
               .Single(b => b.Id == entityToUpdate.Id);

            entityToUpdate.Name = entity.Name;

            _beerStoreContext.SaveChanges();
        }

      
        public IEnumerable<Brewery> GetAll(decimal? gtAlcoholByVolume = null, decimal? ltAlcoholByVolume = null)
        {
            throw new NotImplementedException();
        }


    }
}
