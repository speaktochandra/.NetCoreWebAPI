﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using BeerProject.Models;

namespace BeerProjectTest.MockData
{
    internal class BeerMockData
    {
        public static List<Beer> GetBeers()
        {
            return new List<Beer>{
             new Beer{
                 Name = "Beer_" + Guid.NewGuid().ToString(),
                 PercentageAlcoholByVolume = 5
             },
            new Beer{
                 Name = "Beer_" + Guid.NewGuid().ToString(),
                 PercentageAlcoholByVolume = 2
             },
            new Beer{
                Name = "Beer_" + Guid.NewGuid().ToString(),
                 PercentageAlcoholByVolume = 3
             }
         };
        }
    }
}
