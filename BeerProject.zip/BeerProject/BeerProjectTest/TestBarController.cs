﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BeerProject.Models.DataManager;
using BeerProject.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using BeerProject.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace BeerProjectTest
{
    public class TestBarController
    {
        private BarDataManager repository;
        public static DbContextOptions<BeerStoreContext> dbContextOptions { get; set; }

        public TestBarController()
        {
            var config = new ConfigurationBuilder()
           .AddJsonFile("appsettings.json")
           .Build();
            var connectionString = config["ConnectionStrings:BeerStoreDb_ForUnitTest_Bar"];
            dbContextOptions = new DbContextOptionsBuilder<BeerStoreContext>()
                .UseSqlServer(connectionString)
                .Options;

            var context = new BeerStoreContext(dbContextOptions);
            //context.Database.EnsureDeleted(); 
            context.Database.EnsureCreated();
            repository = new BarDataManager(context);

        }

        [Fact]
        public void Insert_Return_OkResult()
        {
            //Arrange
            var controller = new BarController(repository);
            List<Beer> beers = new List<Beer>
            {
                new Beer { Name = "NewBeer_Bar_Test_1", PercentageAlcoholByVolume = 6 },
                new Beer { Name = "NewBeer_Bar_Test_2", PercentageAlcoholByVolume = 4 }
            };

            Bar bar = new Bar { Name = "New Bar_1", Address = "New BarAddress_1", Beers = beers};

            //Act
            var data = controller.Post(bar);

            //Assert
            Assert.IsType<CreatedAtRouteResult>(data);
        }

    }
}
