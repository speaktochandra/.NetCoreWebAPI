﻿using BeerProject.Models.Repository;
using BeerProject.Models.DTO;
using System.Linq;

namespace BeerProject.Models.DataManager
{
    public class BeerDataManager : IDataRepository<Beer, BeerDto>
    {
         readonly BeerStoreContext _beerStoreContext;

        public BeerDataManager(BeerStoreContext storeContext)
        {
            _beerStoreContext = storeContext;
        }

        // Insert Beer to DB using EF core
        public void Add(Beer entity)
        {
            _beerStoreContext.Beers.Add(entity);
            _beerStoreContext.SaveChanges();
        }

        // Update Beer back to DB
        public void Update(Beer entityToUpdate, Beer entity)
        {

            entityToUpdate = _beerStoreContext.Beers
                .Single(b => b.Id == entityToUpdate.Id);

            entityToUpdate.Name = entity.Name;
            entityToUpdate.PercentageAlcoholByVolume = entity.PercentageAlcoholByVolume;

            _beerStoreContext.SaveChanges();

        }

        // Get all beers by passing optional params gtAlcoholByVolume ltAlcoholByVolume
        public IEnumerable<Beer> GetAll(decimal? gtAlcoholByVolume, decimal? ltAlcoholByVolume)
        {
            return _beerStoreContext.Beers
               .Where(gtAlcoholByVolume != null? x => x.PercentageAlcoholByVolume > gtAlcoholByVolume: x => x.PercentageAlcoholByVolume != -1)
               .Where(ltAlcoholByVolume != null? x => x.PercentageAlcoholByVolume < ltAlcoholByVolume : x => x.PercentageAlcoholByVolume != -1)
               .ToList();
        }
        
        // Get beer by id from the DB using EF Core
        public Beer Get(long id)
        {
            var Beer = _beerStoreContext.Beers
                .SingleOrDefault(b => b.Id == id);

            if (Beer == null)
            {
                return null;
            }

            return Beer;
        }

      

        public IEnumerable<Beer> GetAll()
        {
            throw new NotImplementedException();
        }

        public Beer GetWithAssociatedEntity(long id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Beer> GetAllWithAssociatedEntity()
        {
            throw new NotImplementedException();
        }

         
    }
}
