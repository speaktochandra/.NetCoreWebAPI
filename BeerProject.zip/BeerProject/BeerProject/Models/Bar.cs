﻿using System;
using System.Collections.Generic;

namespace BeerProject.Models;

public partial class Bar
{
    public long Id { get; set; }

    public string Name { get; set; } = null!;

    public string Address { get; set; } = null!;

    public virtual ICollection<Beer> Beers { get; set; } = new List<Beer>();
}
