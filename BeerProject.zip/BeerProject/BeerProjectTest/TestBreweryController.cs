﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BeerProject.Models.DataManager;
using BeerProject.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using BeerProject.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace BeerProjectTest
{
    public class TestBreweryController
    {

    private BreweryDataManager repository;
    public static DbContextOptions<BeerStoreContext> dbContextOptions { get; set; }

    public TestBreweryController()
    {
        var config = new ConfigurationBuilder()
        .AddJsonFile("appsettings.json")
       .Build();
        var connectionString = config["ConnectionStrings:BeerStoreDb_ForUnitTest_Brewery"];
        dbContextOptions = new DbContextOptionsBuilder<BeerStoreContext>()
            .UseSqlServer(connectionString)
            .Options;

        var context = new BeerStoreContext(dbContextOptions);
        //context.Database.EnsureDeleted(); 
        context.Database.EnsureCreated();
        repository = new BreweryDataManager(context);

    }

        [Fact]
        public void Insert_Return_OkResult()
        {
            //Arrange
            var controller = new BreweryController(repository);
            List<Beer> beers = new List<Beer>
            {
                new Beer { Name = "NewBeer_Brewery_Test_1", PercentageAlcoholByVolume = 6 },
                new Beer { Name = "NewBeer_Brewery_Test_2", PercentageAlcoholByVolume = 4 }
            };

            Brewery brewery = new Brewery { Name = "New Bar_1", Beers = beers };

            //Act
            var data = controller.Post(brewery);

            //Assert
            Assert.IsType<CreatedAtRouteResult>(data);
        }

    }
}