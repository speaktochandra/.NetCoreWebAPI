﻿using BeerProject.Models;
using FluentValidation;

namespace BeerProject.Validation
{
    public class BarValidator : AbstractValidator<Bar>
    {
        public BarValidator()
        {

            // Validate Name with a custom error message
            RuleFor(bar => bar.Name)
                .NotEmpty().WithMessage("Please add a Name")
                .NotNull().WithMessage("Please provide Name");

            // Validate Address with a custom error message
            RuleFor(bar => bar.Address)
                .NotEmpty().WithMessage("Please add a Address")
                .NotNull().WithMessage("Please provide Address");

        }
    }
}
