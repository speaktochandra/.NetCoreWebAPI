using BeerProject.Controllers;
using BeerProject.Models;
using BeerProject.Models.DTO;
using BeerProject.Models.Repository;
using Microsoft.EntityFrameworkCore;
using FluentAssertions;
using Xunit;
using BeerProject.Models.DataManager;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;

namespace BeerProjectTest
{
    public class TestBeerController  
    {
        private BeerDataManager repository;
        public static DbContextOptions<BeerStoreContext> dbContextOptions { get; set; }
        private BeerStoreContext context;
        public TestBeerController()     
        {
            var config = new ConfigurationBuilder()
           .AddJsonFile("appsettings.json")
           .Build();
            var connectionString = config["ConnectionStrings:BeerStoreDb_ForUnitTest_Beer"];
            dbContextOptions = new DbContextOptionsBuilder<BeerStoreContext>()
                .UseSqlServer(connectionString)
                .Options;
            context = new BeerStoreContext(dbContextOptions);


            repository = new BeerDataManager(context);

        }

        [Fact]
        public async void Get_Return_OkResult()
        {
            //Arrange
            var controller = new BeerController(repository);

            var context = new BeerStoreContext(dbContextOptions);
            DummyDataDBInitializer db = new DummyDataDBInitializer(context);
            db.Seed(context);

            //Act
            var data = controller.Get();

            //Assert
            Assert.IsType<OkObjectResult>(data);
        }

        [Fact]
        public async void GetById_Return_OkResult()
        {
            //Arrange
            var controller = new BeerController(repository);


            //Act
            var data = controller.Get(1);

            //Assert
            Assert.IsType<OkObjectResult>(data);
        }

        [Fact]
        public async void UpdateById_Return_OkResult()
        {
            //Arrange
            var controller = new BeerController(repository);
            Beer beer = new Beer {Name= "New Beer", PercentageAlcoholByVolume = 3 };

            //Act
            var data = controller.Put(1, beer);

            //Assert
            Assert.IsType<NoContentResult>(data);
        }

        [Fact]
        public async void Insert_Return_OkResult()
        {
            //Arrange
            var controller = new BeerController(repository);
            Beer beer = new Beer { Name = "New Beer_1", PercentageAlcoholByVolume = 5 };

            //Act
            var data = controller.Post(beer);

            //Assert
            Assert.IsType<CreatedAtRouteResult>(data);
        }

        [Fact]
        public async void InsertInvalid_Return_OkResult()
        {
            //Arrange
            var controller = new BeerController(repository);
            Beer beer = null;

            //Act
            var data = controller.Post(beer);

            //Assert
            Assert.IsType<BadRequestObjectResult>(data);
        }

        
    }

    public class DummyDataDBInitializer
    {
        public DummyDataDBInitializer(BeerStoreContext context)
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

        }

        public void Seed(BeerStoreContext context)
        {
            context.Beers.AddRange(
                 MockData.BeerMockData.GetBeers()
            );
            
            context.SaveChanges();
        }

    }

     
    }