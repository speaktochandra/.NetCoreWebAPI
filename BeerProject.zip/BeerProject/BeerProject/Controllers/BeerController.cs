﻿using BeerProject.Models.Repository;
using Microsoft.AspNetCore.Mvc;
using BeerProject.Models;
using BeerProject.Models.DTO;

namespace BeerProject.Controllers
{
    [Route("/beer")]
    [ApiController]
    public class BeerController : Controller
    {

        private readonly IDataRepository<Beer, BeerDto> _dataRepository;

        public BeerController(IDataRepository<Beer, BeerDto> dataRepository)
        {
            _dataRepository = dataRepository;
        }


         
        [HttpGet]
        // Endpoint to get all beers with optiona parameters gtAlcoholByVolume ltAlcoholByVolume
        // - GET /beer?gtAlcoholByVolume=5.0&ltAlcoholByVolume=8.0 - Get all beers with optional filtering query parameters for alcohol content (gtAlcoholByVolume = greater than, ltAlcoholByVolume = less than)
        public IActionResult Get(decimal? gtAlcoholByVolume = null, decimal? ltAlcoholByVolume = null)
        {
            var beers = _dataRepository.GetAll(gtAlcoholByVolume, ltAlcoholByVolume);
            return Ok(beers);
        }

        // GET: /Beer/5
        [HttpGet("{id}", Name = "GetBeer")]
        // Endpoint to get beer by Id 
        //- GET /beer/{id} - Get beer by Id 
        public IActionResult Get(int id)
        {
            var Beer = _dataRepository.Get(id);
            if (Beer == null)
            {
                return NotFound("Beer not found.");
            }

            return Ok(Beer);
        }

        
        [HttpPut("{id}")]
        // Endpoint to update a beer by Id
        // - PUT /beer/{id} - Update a beer by Id
        public IActionResult Put(int id, [FromBody] Beer beer)
        {
            if (beer == null)
            {
                return BadRequest("Beer is null.");
            }

            var beerToUpdate = _dataRepository.Get(id);
            if (beerToUpdate == null)
            {
                return NotFound("The Beer record couldn't be found.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            _dataRepository.Update(beerToUpdate, beer);
            return NoContent();
        }

         
        [HttpPost]
        // Endpoint to insert signle beer
        // - POST /beer - Insert a single beer
        public IActionResult Post([FromBody] Beer beer)
        {
            if (beer is null)
            {
                return BadRequest("Beer is null.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            _dataRepository.Add(beer);
            return CreatedAtRoute("GetBeer", new { Id = beer.Id }, null);
        }
    }
}
