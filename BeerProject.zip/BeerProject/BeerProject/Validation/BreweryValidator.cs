﻿using BeerProject.Models;
using FluentValidation;

namespace BeerProject.Validation
{
    public class BreweryValidator : AbstractValidator<Brewery>
    {
        public BreweryValidator()
        {

            // Validate Name with a custom error message
            RuleFor(brewery => brewery.Name)
                .NotEmpty().WithMessage("Please add a Name")
                .NotNull().WithMessage("Please provide Name");
        }
    }
}
