﻿using System;
using System.Collections.Generic;

namespace BeerProject.Models;

public partial class Beer
{
    public long Id { get; set; }

    public string Name { get; set; } = null!;

    public decimal PercentageAlcoholByVolume { get; set; }

    public long? BarId { get; set; }

    public long? BreweryId { get; set; }

    public virtual Bar? Bar { get; set; }

    public virtual Brewery? Brewery { get; set; }
}
