﻿using BeerProject.Models;
using FluentValidation;

namespace BeerProject.Validation
{
    public class BeerValidator : AbstractValidator<Beer>
    {
        public BeerValidator()
        {
            // Validate Name with a custom error message
            RuleFor(beer => beer.Name)
                .NotEmpty().WithMessage("Please add a Name")
                .NotNull().WithMessage("Please provide Name");

            // Validate PercentageAlcoholByVolume for submitted beer has to be between 0 and 100
            RuleFor(beer => beer.PercentageAlcoholByVolume)
                .InclusiveBetween(0,100) .WithMessage("Please provide PercentageAlcoholByVolume between 0 to 100");

        }
    }
}
