﻿namespace BeerProject.Models.DTO
{
    public class BeerDto
    {
        public int Id { get; set; }

        public string Name { get; set; } = null!;

        public decimal PercentageAlcoholByVolume { get; set; }

        public long? BarId { get; set; }

        public long? BreweryId { get; set; }

        public virtual Bar? Bar { get; set; }

        public virtual Brewery? Brewery { get; set; }

    }
}
