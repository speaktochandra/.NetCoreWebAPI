﻿using BeerProject.Models.DTO;
using BeerProject.Models.Repository;
using BeerProject.Models;
using Microsoft.AspNetCore.Mvc;

namespace BeerProject.Controllers
{
    [Route("/Brewery")]
    [ApiController]
    public class BreweryController : Controller
    {
        private readonly IDataRepository<Brewery, BreweryDto> _dataRepository;

        public BreweryController(IDataRepository<Brewery, BreweryDto> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpPost]
        //EndPoint for below 2 cases 
        //Case1: - POST /brewery - Insert a single brewery
        //Case2: - POST /brewery/beer - Insert a single brewery beer link
        //If beer is not provided in JSON, it will be Case1,
        //else it will be Case2 - Brewery with associated beer will be inseted.

        public IActionResult Post([FromBody] Brewery brewery)
        {
            if (brewery is null)
            {
                return BadRequest("Brewery is null.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            _dataRepository.Add(brewery);
            return CreatedAtRoute("GetBrewery", new { Id = brewery.Id }, null);
        }

        [HttpPut("{id}")]
        // Endpoint to Update the Brewery details by id
        //- PUT /brewery/{id} - Update a brewery by Id
        public IActionResult Put(int id, [FromBody] Brewery brewery)
        {
            if (brewery == null)
            {
                return BadRequest("brewery is null.");
            }

            var BreweryToUpdate = _dataRepository.Get(id);
            if (BreweryToUpdate == null)
            {
                return NotFound("The brewery record couldn't be found.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            _dataRepository.Update(BreweryToUpdate, brewery);
            return NoContent();
        }

        

        [HttpGet("{id}", Name = "GetBrewery")]
        // Endpoint to get Brewery by id
        // - GET /brewery/{id} - Get brewery by Id
        public IActionResult Get(int id)
        {
            var breweries = _dataRepository.Get(id);
            if (breweries == null)
            {
                return NotFound("Brewery not found.");
            }

            return Ok(breweries);
        }

        [Route("/brewery/breweryId/beer")]
        [HttpGet]
        // Endpoint to get brewery (along with associated beers) by id 
        //- GET /brewery/{breweryId}/beer - Get a single brewery by Id with associated beers
        public IActionResult Get(long breweryId)
        {
            var bar = _dataRepository.GetWithAssociatedEntity(breweryId);
            if (bar == null)
            {
                return NotFound("Bar not found.");
            }

            return Ok(bar);
        }


        [HttpGet]
        // Enpoint to get All Breweries
        // - GET /brewery - Get all breweries
        public IActionResult Get()
        {
            var breweries = _dataRepository.GetAll();
            return Ok(breweries);
        }

        [Route("/brewery/beer")]
        [HttpGet]
        // Enpoint to get All Breweries with associated beers
        // - GET /brewery/beer - Get all breweries with associated beers
        public IActionResult Get(string? beer)
        {
            var brewery = _dataRepository.GetAllWithAssociatedEntity();
            if (brewery == null)
            {
                return NotFound("brewery not found.");
            }

            return Ok(brewery);
        }



    }
}
