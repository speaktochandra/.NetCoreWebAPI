﻿using BeerProject.Models.DTO;
using BeerProject.Models.Repository;
using Microsoft.EntityFrameworkCore;

namespace BeerProject.Models.DataManager
{
    public class BarDataManager : IDataRepository<Bar, BarDto>
    {
        readonly BeerStoreContext _beerStoreContext;

        public BarDataManager(BeerStoreContext storeContext)
        {
            _beerStoreContext = storeContext;
        }

        // It gets all Bars from DB using EF core
        public IEnumerable<Bar> GetAll()
        {
            return _beerStoreContext.Bars
               .ToList();
        }

        // It gets all Bars with associated Beers from DB using EF core
        //egar loagding to get associated beers
        public IEnumerable<Bar> GetAllWithAssociatedEntity()
        {
            return _beerStoreContext.Bars
                .Include(bar=>bar.Beers)
               .ToList();
        }

        // It gets bar by passing id parameter
        public Bar Get(long id)
        {
            var Bar = _beerStoreContext.Bars
                .SingleOrDefault(b => b.Id == id);

            if (Bar == null)
            {
                return null;
            }

            return Bar;
        }
        //It gets bar with associated beers by passing id
        public Bar GetWithAssociatedEntity(long id)
        {
            var Bar = _beerStoreContext.Bars
                .Include(b => b.Beers)
                .SingleOrDefault(b => b.Id == id);

            if (Bar == null)
            {
                return null;
            }

            return Bar;
        }
        // Insert bar to DB using EF Core
        public void Add(Bar entity)
        {
            _beerStoreContext.Bars.Add(entity);
            _beerStoreContext.SaveChanges();
        }

        // Update the bar back to DB
        public void Update(Bar entityToUpdate, Bar entity)
        {
            entityToUpdate = _beerStoreContext.Bars
               .Single(b => b.Id == entityToUpdate.Id);

            entityToUpdate.Name = entity.Name;
            entityToUpdate.Address = entity.Address;

            _beerStoreContext.SaveChanges();
        }

        public IEnumerable<Bar> GetAll(decimal? gtAlcoholByVolume = null, decimal? ltAlcoholByVolume = null)
        {
            throw new NotImplementedException();
        }

    }
}
