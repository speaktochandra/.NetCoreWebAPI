using BeerProject.Models.Repository;
using BeerProject.Models.DataManager;
using BeerProject.Models.DTO;
using BeerProject.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.Json.Serialization;
using FluentValidation.AspNetCore;
using System.Reflection;
var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers()
    .AddJsonOptions(x =>
                x.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles)
    .AddFluentValidation(options =>
    {
        // Validate child properties and root collection elements
        options.ImplicitlyValidateChildProperties = true;
        options.ImplicitlyValidateRootCollectionElements = true;

        // Automatic registration of validators in assembly
        options.RegisterValidatorsFromAssembly(Assembly.GetExecutingAssembly());
    });
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<BeerStoreContext>(opts => opts.UseSqlServer(builder.Configuration.GetConnectionString("BeerStoreDb")));
builder.Services.AddScoped<IDataRepository<Beer, BeerDto>, BeerDataManager>();
builder.Services.AddScoped<IDataRepository<Bar, BarDto>, BarDataManager>();
builder.Services.AddScoped<IDataRepository<Brewery, BreweryDto>, BreweryDataManager>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
